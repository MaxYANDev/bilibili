# 哔哩哔哩 Kodi 插件

### 下载

插件下载地址: [plugin.video.bili-master.zip](https://github.com/chen310/plugin.video.bili/archive/refs/heads/master.zip)

### 截图

![主页](public/home.png)
![设置](public/settings.png)
![视频](public/video.png)

### 感谢

- [plugin.video.bilibili](https://github.com/zhengfan2014/xbmc-kodi-private-china-addons/tree/py3/plugin.video.bilibili)
- [danmaku2ass](https://github.com/m13253/danmaku2ass)
- [plugin.video.youtube](https://github.com/anxdpanic/plugin.video.youtube)
